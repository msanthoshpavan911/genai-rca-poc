# Spring Boot Quality Starter

Setup:
1. git config core.hooksPath .githooks
2. Add Checkstyle, PMD, SpotBugs, JaCoCo plugins to pom.xml
3. Generate docs under /docs using Copilot Agent
4. Use the instruction file under .github/instructions
5. Protect main branch and enforce CI quality gates
