# Architecture

Populate after repository scan.
