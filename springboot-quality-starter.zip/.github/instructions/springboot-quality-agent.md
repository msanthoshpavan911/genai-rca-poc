# Spring Boot Quality Agent

1. Read repository-index.md and architecture.md first.
2. Analyze only impacted modules.
3. Fix Checkstyle, PMD and SpotBugs issues.
4. Generate/update JUnit5 and Mockito tests.
5. Verify coverage >= 95%.
6. Follow SOLID and Clean Code.
7. Use constructor injection.
8. Produce a root cause and fix summary.
